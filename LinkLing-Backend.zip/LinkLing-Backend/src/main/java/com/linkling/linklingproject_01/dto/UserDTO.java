package com.linkling.linklingproject_01.dto;

public class UserDTO {
}
